package structAdv

func NewABA() *DB {
	aba := New(0, 0)
	return aba
}
