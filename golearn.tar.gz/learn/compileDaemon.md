# compileDaemon

- watch project "api-test"

```
compiledaemon -command="./api-test"
```
