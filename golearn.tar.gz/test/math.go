package math

func Add(x, y int) (res int) {
	return x + y
}
