
insert into account (id, holder, balance) values (1, 'Filippo Thibodeaux', 500);
insert into account (id, holder, balance) values (2, 'Alexi Rate', 400);
insert into account (id, holder, balance) values (3, 'Phyllys Goode', 300);
insert into account (id, holder, balance) values (4, 'Allayne Perrie', 200);
insert into account (id, holder, balance) values (5, 'Louisa Braddick', 100);
