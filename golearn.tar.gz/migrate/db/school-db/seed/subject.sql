create table if not exists subject (
	id INT,
	teacher_id INT,
	title VARCHAR(50)
);
insert into subject (id, teacher_id, title) values (1, 7, 'Senegal');
insert into subject (id, teacher_id, title) values (2, 9, 'China');
insert into subject (id, teacher_id, title) values (3, 7, 'Portugal');
insert into subject (id, teacher_id, title) values (4, 3, 'Poland');
insert into subject (id, teacher_id, title) values (5, 7, 'Greece');
insert into subject (id, teacher_id, title) values (6, 7, 'Indonesia');
insert into subject (id, teacher_id, title) values (7, 3, 'Iran');
insert into subject (id, teacher_id, title) values (8, 4, 'Bhutan');
insert into subject (id, teacher_id, title) values (9, 4, 'Greece');
insert into subject (id, teacher_id, title) values (10, 3, 'Philippines');
insert into subject (id, teacher_id, title) values (11, 1, 'United States');
insert into subject (id, teacher_id, title) values (12, 9, 'France');
insert into subject (id, teacher_id, title) values (13, 10, 'France');
insert into subject (id, teacher_id, title) values (14, 9, 'Czech Republic');
insert into subject (id, teacher_id, title) values (15, 9, 'Costa Rica');
insert into subject (id, teacher_id, title) values (16, 3, 'New Zealand');
insert into subject (id, teacher_id, title) values (17, 2, 'Kazakhstan');
insert into subject (id, teacher_id, title) values (18, 1, 'United States');
insert into subject (id, teacher_id, title) values (19, 1, 'Brazil');
insert into subject (id, teacher_id, title) values (20, 10, 'China');
insert into subject (id, teacher_id, title) values (21, 1, 'Japan');
insert into subject (id, teacher_id, title) values (22, 5, 'Cuba');
insert into subject (id, teacher_id, title) values (23, 4, 'China');
insert into subject (id, teacher_id, title) values (24, 7, 'China');
insert into subject (id, teacher_id, title) values (25, 8, 'Poland');
insert into subject (id, teacher_id, title) values (26, 10, 'Portugal');
insert into subject (id, teacher_id, title) values (27, 7, 'Mozambique');
insert into subject (id, teacher_id, title) values (28, 3, 'China');
insert into subject (id, teacher_id, title) values (29, 6, 'Indonesia');
insert into subject (id, teacher_id, title) values (30, 5, 'Portugal');
