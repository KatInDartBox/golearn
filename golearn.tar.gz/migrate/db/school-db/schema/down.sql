drop table if exists 
  student,teacher,subject,
  subject_student,tbempty;