#! /usr/bin/bash

source "./02role.up.sh"
source "./03schema.up.sh"
source "./04seed.up.sh"
source "./05sequence.sh"
