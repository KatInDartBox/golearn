#! /usr/bin/bash

source "./03schema.down.sh"
source "./03schema.up.sh"
